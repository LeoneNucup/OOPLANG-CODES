
public class CreatePolicies
{
     public static void main(String[] args)
     {
        CarInsurancePolicy(1111,5,"Mexico");
        CarInsurancePolicy(1111,5);
        CarInsurancePolicy(1111);
    
    }
    
    public static void CarInsurancePolicy(int policy_number,int payment_numbers,String residentCity){
        System.out.println("\nThree Arguments\nInsurance Policy Data " + "\nPolicy Number: " + policy_number + "\nPayment Number: " + payment_numbers+ "\nCity of Residence: " + residentCity);
    
    
    }
    
    public static void CarInsurancePolicy(int policy_number,int payment_numbers){
        String residentCity = "Angeles";
        
        System.out.println("\nTwo Arguments\nInsurance Policy Data " + "\nPolicy Number: " + policy_number + "\nPayment Number: " + payment_numbers+ "\nCity of Residence: " + residentCity);
    
    
    }
    
    public static void CarInsurancePolicy(int policy_number){
        String residentCity = "Angeles";
        int payment_numbers = 2;
        System.out.println("\nOne Argument\nInsurance Policy Data " + "\nPolicy Number: " + policy_number + "\nPayment Number: " + payment_numbers+ "\nCity of Residence: " + residentCity);
        
    
    }
    

    
    
    
}
